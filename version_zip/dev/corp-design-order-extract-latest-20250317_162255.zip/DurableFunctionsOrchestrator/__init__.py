# This function is not intended to be invoked directly. Instead it will be
# triggered by an HTTP starter function.
# Before running this sample, please:
# - create a Durable activity function (default name is "Hello")
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import logging
import json

from azure.durable_functions import DurableOrchestrationContext, Orchestrator
from ..system.data_repository import data_repository,master_json
from ..Templates.views import  render_purchase_order_summary,render_no_valid_attachments_message 
from ..system.Utilities import Utility
import os 

ALLOWED_EXTENSIONS = {".pdf", ".xls", ".xlsx"}


def get_valid_attachments(attachments):
    valid_attachments=[]
    for attachment in attachments:
        filename = attachment['Name']
        file_extension = os.path.splitext(filename)[1].lower()
        if file_extension not in ALLOWED_EXTENSIONS:
            logging.warning(f"Skipping file {filename} with unsupported extension {file_extension}.")
            continue 
        valid_attachments.append(attachment)
    return valid_attachments
def orchestrator_function(context: DurableOrchestrationContext):
    attachments = context.get_input()

    if attachments is None:
        logging.error("No input received by orchestrator.")
        return {"error": "No input received."}

    logging.info(f"Orchestrator received input: {attachments}")

    valid_attachments = get_valid_attachments(attachments)
    if not valid_attachments:
        return {
            "data": render_no_valid_attachments_message(),
            "subject": "No valid attachments found"
        }
    parallel_tasks = [context.call_activity('ProcessPDFActivity', name) for name in valid_attachments]
    result = yield context.task_all(parallel_tasks)

    result, subject = Utility.generate_total(result)
    final_json_data = json.dumps(result, indent=4)
    data_repository.load_json_to_blob(final_json_data)

    result = render_purchase_order_summary(result)

    return {
        "data": result,
        "subject": subject
    }


main = Orchestrator.create(orchestrator_function)