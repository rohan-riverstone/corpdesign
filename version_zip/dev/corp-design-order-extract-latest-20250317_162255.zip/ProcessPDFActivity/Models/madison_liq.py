import re
import logging
from ...system.Utilities import Utility
from ..BL.part_number_map import product_mapper


class MadisonLiq:

    def extract_address(self, address):
        address_dict = {
            "address1": "",
            "address2": "",
            "city": "",
            "state": "",
            "zip_code": "",
        }

        # Regex for extracting zip code
        zip_pattern = re.compile(r"(\d{5})$")
        zip_match = zip_pattern.search(address)
        if zip_match:
            address_dict["zip_code"] = zip_match.group(1).strip()
            address = address[
                : zip_match.start()
            ].strip()  # Remove zip code from address

        # Regex for extracting state (abbreviation or full name)
        state_pattern = re.compile(r"\s*,\s*([A-Z]{2}|[A-Za-z ]+)$")
        state_match = state_pattern.search(address)
        if state_match:
            address_dict["state"] = state_match.group(1).strip()
            address = address[
                : state_match.start()
            ].strip()  # Remove state from address

        # Regex for extracting city
        city_pattern = re.compile(r"\s*,\s*([A-Za-z ]+)$")
        city_match = city_pattern.search(address)
        if city_match:
            address_dict["city"] = city_match.group(1).strip()
            address = address[: city_match.start()].strip()  # Remove city from address

        # The remaining part is address1
        address_dict["address1"] = address.strip()

        return address_dict

    def extract_vendor_address(self, order, tolerance=0.05):
        # Define the bounding box based on the provided polygons
        ref_bounds = {
            "min_x": 0.4191 - tolerance,
            "max_x": 1.7431 + tolerance,
            "min_y": 1.6106 - tolerance,
            "max_y": 2.0358 + tolerance,
        }

        address_lines = []  # Store all matching lines

        for page in order.pages:
            for item in page.lines:
                if not item.polygon:
                    continue

                bounds = {
                    "min_x": min(p[0] for p in item.polygon),
                    "max_x": max(p[0] for p in item.polygon),
                    "min_y": min(p[1] for p in item.polygon),
                    "max_y": max(p[1] for p in item.polygon),
                }

                if (
                    ref_bounds["min_x"] <= bounds["min_x"] <= ref_bounds["max_x"]
                    and ref_bounds["min_x"] <= bounds["max_x"] <= ref_bounds["max_x"]
                    and ref_bounds["min_y"] <= bounds["min_y"] <= ref_bounds["max_y"]
                    and ref_bounds["min_y"] <= bounds["max_y"] <= ref_bounds["max_y"]
                ):

                    address_lines.append(
                        item.content.strip().replace("-", "")
                    )  # Collect text

        return address_lines  # Return full address

    def extract_clean_product_code(self, text):
        text = text.replace("\n", " ")

        text = re.sub(r"(Corp|Design|:|\s+)", "", text, flags=re.IGNORECASE)

        match = re.search(r"(CD-[A-Za-z0-9-]+)", text)

        return match.group(1) if match else ""

    def find_purchase_order(self, invoice_document):
        possible_keys = ["PurchaseOrder", "InvoiceId"]
        for key in possible_keys:
            field = invoice_document.fields.get(key)
            if field and field.value:
                return re.sub(r"[^A-Za-z0-9]+", "", field.value)
        return ""

    def extract_data_from_table(self, order):
        extracted_items = []

        for table in order.tables:
            rows = {}

            for cell in table.cells:
                if cell.row_index not in rows:
                    rows[cell.row_index] = {}
                rows[cell.row_index][cell.column_index] = cell.content.strip()

            number_pattern = re.compile(r"^\d{1,3}(,\d{3})*(\.\d+)?$")

            for row_index in sorted(rows.keys()):
                product_code = rows[row_index].get(0, "")
                if (
                    product_code is None
                    or product_code.lower().strip() == "services:shipcd"
                    or "services" in product_code.lower()
                    or "CD" not in product_code
                ):
                    continue
                elif product_code.lower().strip() == "corp" and (row_index + 1) in rows:
                    product_code += rows[row_index + 1].get(0, "")

                description = rows[row_index].get(1, "")
                if description is None:
                    continue

                qty = rows[row_index].get(2, "0").strip()
                unit_price = rows[row_index].get(3, "0.0").strip()
                amount = rows[row_index].get(4, "0.0").strip()

                qty = int(qty) if qty.isdigit() else 0

                unit_price = (
                    float(unit_price.replace(",", ""))
                    if number_pattern.match(unit_price)
                    else 0.0
                )
                amount = (
                    float(amount.replace(",", ""))
                    if number_pattern.match(amount)
                    else 0.0
                )

                if qty == 0 and amount == 0.0 and unit_price == 0.0:
                    continue
                product_code = self.extract_clean_product_code(product_code)
                #  extraction from excel
                extracted_items.append(
                    {
                        "product_code": product_code,
                        "description": description,
                        "qty": qty,
                        "unit_price": unit_price,
                        "amount": amount,
                        "pdf_product_code": product_code,
                    }
                )

        return extracted_items

    def process_data(self, data, customer_name):
        try:
            order = data.result()
            result_data = {}
            result_data["customer_name"] = customer_name

            for invoice_document in order.documents:
                result_data["purchase_order"] = self.find_purchase_order(
                    invoice_document
                )

                invoice_date = invoice_document.fields.get("InvoiceDate")
                if invoice_date and invoice_date.value:
                    result_data["invoice_date"] = invoice_date.value.strftime(
                        "%m/%d/%Y"
                    )

                shiping_address = invoice_document.fields.get("ShippingAddress")
                if shiping_address and shiping_address.value:
                    result_data["shipping_address"] = Utility.splitted_address(
                        shiping_address.value.to_dict()
                    )

                if (
                    isinstance(result_data["shipping_address"], list)
                    and result_data["shipping_address"]
                ):
                    if not result_data["shipping_address"][0].get("city"):
                        address = shiping_address.value.to_dict()
                        result_data["shipping_address"][0]["city"] = address.get(
                            "city_district", ""
                        )

                vendor_address = self.extract_vendor_address(order)

                # print("vendor_address:",vendor_address)
                print("vendor_address:", vendor_address)
                if vendor_address and len(vendor_address) >= 2:
                    address = vendor_address[1]
                    city_state_zip = (
                        vendor_address[2] if len(vendor_address) > 2 else ""
                    )

                    city, state, zip_code = "", "", ""
                    if city_state_zip:
                        parts = city_state_zip.split(",")
                        city = parts[0].strip() if len(parts) > 0 else ""
                        state_zip = parts[1].strip() if len(parts) > 1 else ""

                        state_zip_split = re.split(r"\s+", state_zip)
                        state = state_zip_split[0] if len(state_zip_split) > 0 else ""
                        zip_code = (
                            state_zip_split[-1]
                            if len(state_zip_split) > 1
                            and state_zip_split[-1].isdigit()
                            else ""
                        )

                    result = {
                        "address1": (
                            vendor_address[0] if len(vendor_address) > 0 else ""
                        ),
                        "address2": address,
                        "city": city,
                        "state": state,
                        "zip_code": zip_code,
                    }
                result_data["billing_address"] = result

            result_data["order_line_items"] = self.extract_data_from_table(order=order)
            result_data["order_line_items"] = product_mapper.find_best_match(
                result_data["order_line_items"]
            )
            return result_data
        except Exception as ex:
            logging.error(
                f"Madison Liquidator process data is failed. Reason: {str(ex)}"
            )
