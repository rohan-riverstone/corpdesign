import re
from ...system.Utilities import Utility
from ..BL.part_number_map import product_mapper


class OFSOF:
    def extract_part_number_and_description(self, text):
        print("text des ", text)
        text = text.replace("\n", " ").strip()

        # Updated regex pattern to correctly extract the part number
        pattern = r"^(CD-[\w-]+)\s*([A-Z]+-[A-Z]+)?\s*(.*)$"
        match = re.match(pattern, text)

        if match:
            part_number = match.group(1).rstrip(
                "-"
            )  # Remove trailing hyphen if present
            if match.group(2):  # Capture optional suffix like BLK-B
                part_number += "-" + match.group(2).strip()
            description = match.group(3).strip()
            print("part_number, description:", part_number, description)
            return part_number, description

        return None, None

    def clean_product_code(self, product_code):
        if not product_code:
            return ""
        cleaned_code = product_code.replace("\n", "").strip()
        cleaned_code = re.sub(r"\s+", " ", cleaned_code)
        return cleaned_code

    def extract_product_code_from_table(self, description, order):
        for table in order.tables:
            rows = {}
            for cell in table.cells:
                if cell.row_index not in rows:
                    rows[cell.row_index] = {}
                rows[cell.row_index][cell.column_index] = cell.content

            for row_index in sorted(rows.keys()):
                row_desc = rows[row_index].get(1, None)
                if row_desc:
                    part_number, product_description = (
                        self.extract_part_number_and_description(row_desc)
                    )
                    if part_number:
                        return {
                            "part_number": part_number,
                            "description": product_description,
                        }
                    else:
                        part_number, product_description = (
                            self.extract_part_number_and_description(description)
                        )
                        return {
                            "part_number": part_number,
                            "description": product_description,
                        }
        return None

    def process_data(self, data, customer_name):
        order = data.result()
        result_data = {}
        order_line_items = []

        for invoice_document in order.documents:
            result_data["customer_name"] = customer_name

            purchase_order = invoice_document.fields.get("PurchaseOrder")
            if purchase_order and hasattr(purchase_order, "value"):
                purchase_order = re.sub("[^A-Za-z0-9]+", "", purchase_order.value)
            else:
                invoice_id_field = invoice_document.fields.get("InvoiceId")
                purchase_order = (
                    invoice_id_field.value
                    if invoice_id_field and hasattr(invoice_id_field, "value")
                    else None
                )

            if purchase_order:
                result_data["purchase_order"] = purchase_order

            invoice_date = invoice_document.fields.get("InvoiceDate")
            if invoice_date:
                result_data["invoice_date"] = invoice_date.value.strftime("%m/%d/%Y")

            shipping_address = invoice_document.fields.get("ShippingAddress")
            if shipping_address:
                result_data["shipping_address"] = Utility.splitted_address(
                    shipping_address.value.to_dict()
                )

            vendor_address = invoice_document.fields.get("VendorAddress")
            if vendor_address:
                result_data["billing_address"] = Utility.splitted_address(
                    vendor_address.value.to_dict()
                )

            items = invoice_document.fields.get("Items")
            if items and items.value:
                for item in items.value:
                    product_code = (
                        item.value.get("ProductCode")
                        .value.replace(".", "")
                        .replace("\n", "")
                        if item.value.get("ProductCode")
                        else ""
                    )
                    description = (
                        item.value.get("Description").value
                        if item.value.get("Description")
                        else ""
                    )

                    if product_code == "CorpDesign":
                        extracted_part_number, extracted_description = (
                            self.extract_part_number_and_description(description)
                        )
                        if extracted_part_number:
                            product_code = extracted_part_number
                        description = extracted_description

                    if not product_code:
                        extracted_data = self.extract_product_code_from_table(
                            description, order
                        )
                        if extracted_data:
                            product_code = extracted_data["part_number"]
                            description = extracted_data["description"]

                    product_code = self.clean_product_code(product_code)
                    adjusted_product_code = product_code

                    order_line_items.append(
                        {
                            "product_code": adjusted_product_code,
                            "description": (
                                description.replace("\n", "") if description else None
                            ),
                            "qty": (
                                item.value.get("Quantity").value
                                if item.value.get("Quantity")
                                else None
                            ),
                            "unit_price": (
                                item.value.get("UnitPrice").value.amount
                                if item.value.get("UnitPrice")
                                else None
                            ),
                            "amount": (
                                item.value.get("Amount").value.amount
                                if item.value.get("Amount")
                                else None
                            ),
                            "pdf_product_code": adjusted_product_code,
                        }
                    )

            result_data["order_line_items"] = product_mapper.find_best_match(
                order_line_items
            )

        return result_data
